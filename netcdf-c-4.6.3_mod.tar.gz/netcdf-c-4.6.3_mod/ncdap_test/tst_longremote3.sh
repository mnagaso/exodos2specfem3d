#!/bin/sh

export longtests=1
bash ${srcdir}/tst_remote3.sh 
